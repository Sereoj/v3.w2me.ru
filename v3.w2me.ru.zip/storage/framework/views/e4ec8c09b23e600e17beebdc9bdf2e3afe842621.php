<nav class="navbar navbar-light navbar-expand-lg shadow-sm">
    <div class="container">
        <a class="navbar-brand" href="<?php echo e(route('index')); ?>" style="font-family: Roboto, sans-serif;">
            <i class="bi bi-house-door-fill"></i>
            World to Me
        </a><button data-bs-toggle="collapse" class="navbar-toggler" data-bs-target="#navcol-1"><span
                class="visually-hidden">Toggle navigation</span><span
                class="navbar-toggler-icon"></span></button>
        <div class="collapse navbar-collapse" id="navcol-1"
             style="font-family: Roboto, sans-serif;font-size: 14.5px;">
            <ul class="navbar-nav me-auto mb-2 mb-lg-0">
                <li class="nav-item"><a class="nav-link <?php echo e(request()->routeIs('images.new') ? 'active' : ''); ?>" href="<?php echo e(route('images.new')); ?>">Новые</a></li>
                <li class="nav-item"><a class="nav-link <?php echo e(request()->routeIs('images.popular') ? 'active' : ''); ?>" href="<?php echo e(route('images.popular')); ?>">Популярные</a></li>
                <li class="nav-item"><a class="nav-link <?php echo e(request()->routeIs('images.wait') ? 'active' : ''); ?>" href="<?php echo e(route('images.wait')); ?>">Ожидаемые</a></li>

                <?php if(auth()->guard()->check()): ?>
                    <li class="nav-item"><a class="nav-link <?php echo e(request()->routeIs('images.favorite') ? 'active' : ''); ?>" href="<?php echo e(route('images.favorite')); ?>">Избранные</a></li>
                    <li class="nav-item"><a class="nav-link <?php echo e(request()->routeIs('images.install') ? 'active' : ''); ?>" href="<?php echo e(route('images.install')); ?>">Установленные</a></li>
                    <li class="nav-item"><a class="nav-link <?php echo e(request()->routeIs('images.load') ? 'active' : ''); ?>" href="<?php echo e(route('images.load')); ?>">Загружанные</a></li>
                <?php endif; ?>
            </ul>
            <ul class="navbar-nav">
                <li class="nav-item dropdown">
                    <a class="dropdown-toggle nav-link" aria-expanded="false" data-bs-toggle="dropdown" href="#">
                        <i class="bi bi-person-circle"></i> Аккаунт</a>
                    <div class="dropdown-menu">
                        <?php if(auth()->guard()->guest()): ?>
                            <?php if(Route::has('register')): ?>
                                <a class="dropdown-item" href="<?php echo e(route('register')); ?>">Регистрация</a>
                            <?php endif; ?>
                            <?php if(Route::has('login')): ?>
                                <a class="dropdown-item" href="<?php echo e(route('login')); ?>">Авторизация</a>
                            <?php endif; ?>
                        <?php endif; ?>
                        <?php if(auth()->guard()->check()): ?>
                            <a class="dropdown-item" href="<?php echo e(route('user.profile')); ?>">Профиль</a>
                            <a class="dropdown-item" href="<?php echo e(route('logout')); ?>"
                               onclick="event.preventDefault();
                                                     document.getElementById('logout-form').submit();">Выход</a>
                    </div>
                    <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" class="d-none">
                        <?php echo csrf_field(); ?>
                    </form>
                    <?php endif; ?>
                </li>
            </ul>
        </div>
    </div>
</nav>
<?php /**PATH D:\OpenServer\domains\v3.w2me.ru\resources\views/layouts/nav.blade.php ENDPATH**/ ?>