<?php $__env->startSection('content'); ?>
    <div class="row gy-4">
        <h2><?php echo e($header ?? ''); ?></h2>
        <?php $__empty_1 = true; $__currentLoopData = $images; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $image): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
            <div class="col-lg-4 col-md-6">
                <div class="images-list">
                    <a href="<?php echo e(url('catalog',Str::slug($image->name))); ?>">
                        <img src="<?php echo e($image->preview); ?>" loading="lazy" class="img-fluid" style="width: 100%;" alt="Hello">
                    </a>
                    <div class="images-list-text">
                        <h5><?php echo e($image->name); ?></h5>
                    </div>
                </div>
            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
            <p>В данный момент нет изображений.</p>
        <?php endif; ?>
        <nav aria-label="Page navigation">
            <ul class="pagination">
                <li class="page-item"><a class="page-link" href="#">1</a></li>
                <li class="page-item"><a class="page-link" href="#">2</a></li>
                <li class="page-item"><a class="page-link" href="#">3</a></li>
            </ul>
        </nav>
    </div>
<?php $__env->stopSection(); ?>
<?php /**PATH D:\OpenServer\domains\v3.w2me.ru\resources\views/pages/index.blade.php ENDPATH**/ ?>