<?php $__env->startSection('content'); ?>
    <div id="main" data-infinite-scroll='{ "path": ".pagination__next", "append": ".thumb", "status": "scroller-status", "hideNav": ".pagination", "history": false }'>
        <?php $__currentLoopData = $images; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $image): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <article class="thumb">
            <a href="<?php echo e($image->preview); ?>" class="image"><img src="<?php echo e($image->preview); ?>" alt="<?php echo e($image->name); ?>" /></a>
            <h2><?php echo e($image->name); ?></h2>
            <p><?php echo e($image->description); ?></p>
            <a href="#">Открыть страницу</a>
        </article>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
    <p class="pagination">
        <?php if($images->hasMorePages()): ?>
            <a class="pagination__next" href="<?php echo e($images->nextPageUrl()); ?>">Next page</a>
        <?php endif; ?>
    </p>
    <div class="scroller-status">
        <div class="loader-ellips infinite-scroll-request">
            <span class="loader-ellips__dot"></span>
            <span class="loader-ellips__dot"></span>
            <span class="loader-ellips__dot"></span>
            <span class="loader-ellips__dot"></span>
        </div>
        <p class="infinite-scroll-last">End of content</p>
    </div>
<?php $__env->stopSection(); ?>
<?php /**PATH D:\OpenServer\domains\v3.w2me.ru\resources\views/single.blade.php ENDPATH**/ ?>