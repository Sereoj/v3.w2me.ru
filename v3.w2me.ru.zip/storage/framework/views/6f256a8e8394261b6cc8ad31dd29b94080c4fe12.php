[<?php echo e($slot); ?>](<?php echo e($url); ?>)
<?php /**PATH D:\OpenServer\domains\v3.w2me.ru\resources\views/vendor/mail/text/header.blade.php ENDPATH**/ ?>