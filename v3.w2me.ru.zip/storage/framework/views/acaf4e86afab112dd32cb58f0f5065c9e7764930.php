<?php echo e($slot); ?>

<?php /**PATH D:\OpenServer\domains\v3.w2me.ru\vendor\laravel\framework\src\Illuminate\Mail/resources/views/text/footer.blade.php ENDPATH**/ ?>