<?php $__env->startSection('content'); ?>
        <div class="row gy-4">
            <h2><?php echo e($header ?? ''); ?></h2>
                <div class="col col-xl-2 col-md-4 col-lg-3">
                    <div class="photo">
                        <img src="<?php echo e($image); ?>" class="profile">
                    </div>
                    <form class="d-flex" method="POST">
                        <?php echo csrf_field(); ?>
                        <button class="btn btn-primary mx-auto" name="edit" value="true">Редактировать</button>
                    </form>
                </div>
                <div class="col col-xl-8 col-md-6 col-lg-6">
                    <p class="lead">Имя: <?php echo e($user->name); ?></p>
                    <p class="lead">Роль: <?php echo e(__("messages.$role->role")); ?></p>
                    <p class="lead">Тип аккаунта: <?php echo e(__("messages.user_type.$type->type")); ?></p>
                    <p class="lead">Ваш баланс: <?php echo e(__('messages.balance',['cost' => number_format($type->cost)])); ?></p>
                    <p class="lead">Дата создания аккаунта: <?php echo e($user->created_at); ?></p>
                    <?php if($status != true): ?>
                        <form method="POST">
                            <?php echo csrf_field(); ?>
                            <div class="alert alert-danger" role="alert">Подтвердите email: <?php echo e($user->getEmailForVerification()); ?></div>
                            <button class="btn btn-primary btn-sm" name="send" value="true">Отправить</button>
                        </form>
                    <?php endif; ?>
                </div>
        </div>
<?php $__env->stopSection(); ?>
<?php /**PATH D:\OpenServer\domains\v3.w2me.ru\resources\views/pages/profile.blade.php ENDPATH**/ ?>