<?php $__env->startSection('content'); ?>
    <div class="row gy-4">
        <?php if(auth()->guard()->guest()): ?>
            <div class="alert alert-danger" role="alert">Страница не найдена</div>
        <?php endif; ?>
    </div>
<?php $__env->stopSection(); ?>

<?php /**PATH D:\OpenServer\domains\v3.w2me.ru\resources\views/pages/errors/not-found.blade.php ENDPATH**/ ?>