<?php $__env->startSection('content'); ?>
        <div class="row gy-4">
            <?php echo e($images); ?>

        </div>
<?php $__env->stopSection(); ?>
<?php /**PATH D:\OpenServer\domains\v3.w2me.ru\resources\views/pages/simple.blade.php ENDPATH**/ ?>