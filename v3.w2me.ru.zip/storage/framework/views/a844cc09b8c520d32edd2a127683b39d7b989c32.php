<?php echo e($slot); ?>

<?php /**PATH D:\OpenServer\domains\v3.w2me.ru\resources\views/vendor/mail/text/footer.blade.php ENDPATH**/ ?>