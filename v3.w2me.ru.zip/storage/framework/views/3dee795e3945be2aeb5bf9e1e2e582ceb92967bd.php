<?php $__env->startSection('content'); ?>
        <?php if(auth()->guard()->check()): ?>
            <div class="row gy-4">
                <h2><?php echo e($header ?? ''); ?></h2>
                <?php $__empty_1 = true; $__currentLoopData = $images; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $image): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <div class="col-lg-4 col-md-6">
                        <div class="images-list">
                            <a href="<?php echo e(url('catalog',Str::slug($image->name))); ?>">
                                <img src="<?php echo e($image->preview); ?>" loading="lazy" class="img-fluid">
                            </a>
                            <div class="images-list-text">
                                <h5><?php echo e($image->name); ?></h5>
                            </div>
                        </div>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <p>В данный момент нет изображений.</p>
                <?php endif; ?>
            </div>
        <?php endif; ?>

        <?php if(auth()->guard()->guest()): ?>
            <div class="alert alert-danger" role="alert">Нет доступа</div>
        <?php endif; ?>
<?php $__env->stopSection(); ?>
<?php /**PATH D:\OpenServer\domains\v3.w2me.ru\resources\views/pages/install.blade.php ENDPATH**/ ?>