<?php $__env->startSection('content'); ?>
        <div class="row gy-4">
        <h2><?php echo e($header ?? ''); ?></h2>
        <?php if(auth()->guard()->check()): ?>
        <form method="POST">
            <?php echo csrf_field(); ?>
            <table class="table">
                <thead>
                <tr>
                    <th scope="col">№</th>
                    <th>Имя</th>
                    <th>Количество скачиваний</th>
                    <th>Действия</th>
                </tr>
                </thead>
                <tbody>

                <?php $__currentLoopData = $catalog; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($item->id); ?></td>
                        <td><?php echo e($item->name); ?></td>

                        <td><?php echo e($item->download[0]->count_download ?? '0'); ?></td>
                        <td>
                            <button type="submit" class="btn btn-primary" name="change" value="<?php echo e($item->id); ?>">Изменить</button>
                            <button type="submit" class="btn btn-danger" name="delete" value="<?php echo e($item->id); ?>">Удалить</button>
                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
            <button type="submit" class="btn btn-primary" name="add" value="item">Добавить</button>
        </form>
        <?php endif; ?>

        <?php if(auth()->guard()->guest()): ?>
            <div class="alert alert-danger" role="alert">Нет доступа</div>
        <?php endif; ?>
        </div>
<?php $__env->stopSection(); ?>
<?php /**PATH D:\OpenServer\domains\v3.w2me.ru\resources\views/pages/load.blade.php ENDPATH**/ ?>