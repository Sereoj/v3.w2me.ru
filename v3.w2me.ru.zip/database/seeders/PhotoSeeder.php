<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\DB;

class PhotoSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        //name
        //type
        //location
        //photo_typesub_categories
//        DB::table('photo')->insert([
//            [
//                'name' => '',
//                'type' => '',
//                'location' => '',
//                'photo_type' => '',
//            ]
//        ]);
    }
}
