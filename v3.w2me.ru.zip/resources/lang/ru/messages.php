<?php

return [
    'sunrise' => 'Рассвет',
    'day' => 'День',
    'sunset' => 'Закат',
    'night' => 'Ночь',

    'administrator' => 'Администратор',
    'moderator' => 'Модератор',
    'user' => 'Пользователь',

    'user_type.free' => 'Бесплатный',
    'user_type.pay' => 'Платный, действует до:',
    'balance' => ":cost руб.",
    'category' => ":Category",
    'license.pay' => 'Платно',
    'license.free' => 'Бесплатно',
    'username' => ':Name'
];
